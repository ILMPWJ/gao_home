package com.example.webtest1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Webtest1Application {

    public static void main(String[] args) {
        SpringApplication.run(Webtest1Application.class, args);
    }

}
