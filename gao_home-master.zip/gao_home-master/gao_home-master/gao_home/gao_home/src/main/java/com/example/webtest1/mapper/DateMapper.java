package com.example.webtest1.mapper;

import com.example.webtest1.model.Date;
import com.example.webtest1.model.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface DateMapper {
    //
    @Insert("insert into date (point,explanation) values (#{point},#{explanation})")
    void adddate(Date date);

    @Select("select * from date where point=#{point}")
    Date getdate(String point);

    @Delete("delete from date where point=#{point}")
    void deletedate(String point);

    @Update("update date set explanation=#{explanation} where point=#{point}")
    void updatedate(String point,String explanation);

    @Select("select * from date")
    List<Date> getalldates();


    @Insert("insert into user (username,password) values (#{username},#{password})")
    void adduser(User user);

    @Select("select * from user where username=#{username}")
    User getuser(String username);

    @Select("select * from user where username=#{username} and password=#{password}")
    User login(String username, String password);

    @Delete("delete from user where username=#{username}")
    void deleteuser(String username);

    @Update("update user set password=#{password} where username=#{username}")
    void updateuser(String username,String password);

}



