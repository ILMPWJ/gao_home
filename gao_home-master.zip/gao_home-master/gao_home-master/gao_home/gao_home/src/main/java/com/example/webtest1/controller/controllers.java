package com.example.webtest1.controller;

import com.example.webtest1.mapper.DateMapper;
import com.example.webtest1.model.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Controller
public class controllers{
    @Autowired
    private DateMapper dateMapper;

    @GetMapping("register")
    public String reg() {
        return "management";
    }

    @RequestMapping("/register")
    public String register(HttpServletRequest request, Map<String, Object> map) {
        String point = request.getParameter("point");
        String explanation = request.getParameter("explanation");
        Date date = new Date();
        date.setPoint(point);
        date.setExplanation(explanation);
        Date date1 = dateMapper.getdate(point);
        if (date1 != null) {
            map.put("msg1", "该知识点已经添加");
            return "management";
        } else {
            dateMapper.adddate(date);
            return "display";
        }

    }

    @RequestMapping("/getdate")
    public String getdate(HttpServletRequest request, Map<String, Object> map) {
        String point = request.getParameter("point");
        Date date = dateMapper.getdate(point);
        if (date != null) {
            map.put("msg", "此知识点已经记录，可直接查看！");
            return "management";
        } else {
            map.put("msg", "此知识点未记录，可添加记录！");
            return "management";
        }
    }

    @RequestMapping("/update")
    public String login(HttpServletRequest request, Map<String, Object> map) {
        String point = request.getParameter("point");
        String explanation = request.getParameter("explanation");
        Date date = dateMapper.getdate(point);
        if (date != null) {
            map.put("msg2", point + ":" + date.getExplanation());
            return "content";
        } else {
            map.put("msg2", "该知识点不存在！");
            return "content";
        }

    }

    @RequestMapping("/deletedate")
    public String deletedate(HttpServletRequest request, Map<String, Object> map) {
        String point = request.getParameter("point");
        Date getdate = dateMapper.getdate(point);
        if (getdate != null) {
            dateMapper.deletedate(point);
            map.put("msg4", "该知识点已成功删除！");
            return "delete";
        } else {
            map.put("msg4", "该知识点不存在！");
            return "delete";
        }
    }

    @RequestMapping("/updatedate")
    public String update(HttpServletRequest request, Map<String, Object> map) {
        String point = request.getParameter("point");
        String explanation = request.getParameter("explanation");
        Date getdate = dateMapper.getdate(point);
        if (getdate != null) {
            dateMapper.updatedate(point, explanation);
            map.put("msg3", "该知识点详细说明已更新！");
            return "content";
        } else {
            map.put("msg3", "该知识点不存在！");
            return "content";
        }
    }

    @RequestMapping("/display")
    public String getalldates(HttpServletRequest request, Map<String, Object> map) {
        List<Date> dateList = dateMapper.getalldates();
        int count = dateList.size();
        List<Date> newDateList = IntStream.range(0, count)
                .mapToObj(index -> new Date(String.valueOf(index + 1), dateList.get(index).getPoint(), dateList.get(index).getExplanation()))
                .collect(Collectors.toList());
        map.put("dateList", newDateList);
        return "display";
    }


  @RequestMapping("/home")
    public String home(){
        return "home";
    }
}

