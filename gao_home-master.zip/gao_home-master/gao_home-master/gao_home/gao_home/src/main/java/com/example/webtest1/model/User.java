package com.example.webtest1.model;
import lombok.Data;

@Data
public class User {
    private int id;
    private String username;
    private String password;
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }




    /*  public User() {

    }

    public User(int id, String username, String password) {
        this.setId(id);
        this.setUsername(username);
        this.setPassword(password);
    }*/
}


