
package com.example.webtest1.controller;

import com.example.webtest1.mapper.DateMapper;

import com.example.webtest1.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;



import javax.servlet.http.HttpServletRequest;
        import java.util.Map;

@Controller   //如何和页面对应，字符串拼接
public class registerController {
    @Autowired
    private DateMapper dateMapper;

  @GetMapping("/registert")
    @RequestMapping("/registert")
    public String register(){
        return "registert";
    }





    @RequestMapping("/adduser")
    public String adduser(HttpServletRequest request, Map<String,Object> map){
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        System.out.println(username);

        User user=new User();
        user.setUsername(username);//初始化
        user.setPassword(password);
        User user1=dateMapper.getuser(username);
        if(user1!=null){
            map.put("msg1","该用户名已被注册，请重新注册!!!");
            return "/registert";
        }else{
            dateMapper.adduser(user);
            map.put("msg1","注册成功，跳转登录页面");
            return "/login";
        }



    }
    @RequestMapping("/getuser")
    public String getuser(HttpServletRequest request,Map<String,Object> map){
        String username = request.getParameter("username");
        User user = dateMapper.getuser(username);
        if(user!=null){
            map.put("msg","该用户名已存在");
            return "registert";
        }else{
            map.put("msg","恭喜您，该用户名可注册新账号!");
            return "registert";
        }
    }
    @RequestMapping("/login")
    public String login(HttpServletRequest request,Map<String,Object> map){
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        User loginuser = dateMapper.login(username, password);
        System.out.println(loginuser);
        if(loginuser!=null){
            map.put("msg2","the user "+loginuser+" login");
            return "home";
        }
        else{
            map.put("msg2","密码输入错误，请重试！");
            return "login";
        }
    }

    @RequestMapping("/deleteuser")
    public String deleteuser(HttpServletRequest request,Map<String,Object> map){
        String username = request.getParameter("username");
        User getuser = dateMapper.getuser(username);
        if(getuser!=null){
            dateMapper.deleteuser(username);
            map.put("msg3","用户名删除成功!");
            return "deleteuser";
        }else{
            map.put("msg3","此用户不存在");
            return "deleteuser";
        }
    }
    @RequestMapping("/updateuser")
    public String update(HttpServletRequest request,Map<String,Object> map){   //String来拼接字符串
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        User getuser = dateMapper.getuser(username);
        if(getuser!=null){
            dateMapper.updateuser(username,password);
            map.put("msg4","用户名更新成功!");
            return "updateuser";
        }else{
            map.put("msg4","此用户不存在");
            return "updateuser";
        }
    }
}