package com.example.webapp01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Webapp01ApplicationTests {

    @Test
    void contextLoads() {
    }

}
